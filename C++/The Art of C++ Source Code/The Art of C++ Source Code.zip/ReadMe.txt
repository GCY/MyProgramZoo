These files contain all of the code listings in

                The Art of C++

The source code is organized into files by chapter.
Within each chapter file, the listings are stored
in the same order as they appear in the book.
Simply edit the appropriate file to extract the
listing in which you are interested.


