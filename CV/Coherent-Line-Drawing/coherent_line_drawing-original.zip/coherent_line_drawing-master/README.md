# coherent_line_drawing
Coherent Line Drawing standalone program source

Source code was modified from the paper 'Coherent Line Drawing' by Kang et al, Proc. NPAR 2007, to be a standalone program.

The project website for that paper is here:
  http://cg.postech.ac.kr/research/coherent_line/

Install OpenCV and compile with:

```
g++ *.cpp -o main `pkg-config --libs opencv`
```
